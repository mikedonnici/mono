def say():
    return "HELLO"
